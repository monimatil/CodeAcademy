<?php

function masina($a, $b, $c){
    return[
        'Gamintojas' => ucfirst(strtolower($a)),
        'Modelis' => ucfirst(strtolower($b)),
        'Metai' => ucfirst(strtolower($c)),
    ];
}
function isvedimas($m)
{
    $gamintojas = $m['Gamintojas'];
    $modelis = $m['Modelis'];
    $metai = $m['Metai'];

    return '<tr><td>'.$gamintojas.'</td><td>'.$modelis.'</td><td>'.$metai.'</td></tr>';
}

$m[0] = masina('audi', 'A5', '2017');
$m[1] = masina('bmw', 'G5', '2014');
$m[2] = masina('honda', 'F4', '2012');

echo '<table>';
echo '<th>Gamintojas</th><th>Modelis</th><th>Metai</th>';  // lenteles headeris paryskitai paraso
for ($i = 0; $i < count($m); $i++) echo isvedimas($m[$i]); // masyvo $m isveimas i lentele
echo '</table>';






