<?php
//1.
//Sukurkite PHP skriptą, kuriame būtų aprašyti du kintamieji ir ekrane būtų išvestas tų kintamųjų skirtumo šaknis.

$a = 9;
$b = 7;

echo sqrt($a - $b) . '<br>';

//2.
//Sukurkite PHP skriptą, kuriame būtų aprašytas masyvas, aprašantis tris automobilius, kurių kiekvienas yra aprašytas asociatyviniu masyvu naudojant raktus. Asociatyviniuose  masyvuose turi būti laukeliai: gamintojas, modelis, pagaminimo metai, galingumas.

$c = [
    ['BMW', '301i', '2000', '200ag'],
    ['Audi', '100', '1990', '300ag'],
    ['Honda', 'civic', '2005', '300ag']
];
var_dump($c) . '<br>';
echo '<br>';
//3.
//Sukurkite PHP skriptą, kuriame būtų aprašyta funkcija, kuriai padavus tris parametrus ‐ tekstus, funkcija turi grąžinti rezultatą ‐ formatuota tekstą. Teksto formatavimui naudokite šabloną.

function param($d, $d1, $d2){
    $sablonas = 'Sis %s yra %s %s';
    return sprintf($sablonas, $d, $d1, $d2);
}
echo param('rytas', 'labai', 'grazus');
echo '<br>';

//4.
//Sukurkite PHP skriptą, kuriame būtų aprašytas tekstas sudarytas iš žodžių. Suskaidykite tekstą į žodžius ir sukelkite į masyvą. Panaudodami for ciklą ‐ pakeiskite visus masyvo elementus ‐ paversdami tekstą mažosiomis raidėmis, pirmą raidę - didžiąja. Sujunkite visus masyvo elementus į vieną teksto eilutę sujungdami juos vertikaliais '|' brūšniais.

$e = "labas rytas cia as";
$e1 = explode(' ',$e);


for ($i = 0; $i < count($e1); $i++){
    $e1[$i] = ucfirst(strtolower($e1[$i]));
}
echo implode('|',$e1) . '<br>';

//5.
//Sukurkite PHP skriptą, kuriame būtų aprašyta klasė “codeAcademy”, kuri turi savybes ‐ data, skaicius, auditorija. Sukurkite standartinį klasės __construct metodą, kuriam perdavus tris parametrus ‐ data, skaicius, auditorija ‐ perduotus parametrus padėtų į savo savybes.
//6.
//Panaudodami prieš tai sukurtą klasę codeAcademy, sukurkite klases backend ir frontend, kurios paveldi codeAcademy klasę. codeAcademy klasę papildykite metodu “kursas”, kuris išvestų suformatuotą eilutę “data, skaicius, auditorija”. backend klasėje perrašykite metodą duomenys, pakeisdami išvedamą eilutę į “data, skaicius, auditorija (backend kursas)”. backend kursas ‐ tiesiog paprastas žodis. frontend klasėje perrašykite metodą duomenys, pakeisdami išvedamą eilutę į “data, skaicius, auditorija (frontend kursas)”. frontend kursas ‐ tiesiog paprastas žodis. Patkrinkite visų trijų klasių metodo “kursas” veikimą.

class codeAcademy{
    public $data;
    public $skaicius;
    public $auditorija;
    function __construct($da, $sk, $au){
        $this->data = $da;
        $this->skaicius = $sk;
        $this->auditorija = $au;
    }
    function kursas(){
        $ku = "Data: %s, Skaicius: %s, Auditorija: %s";
        return sprintf($ku, $this->data, $this->skaicius, $this->auditorija);
    }
}
$f = new codeAcademy('2017-08-08', '500', '300a');
echo $f->kursas() . '<br>';

class backend extends codeAcademy{
   function pa_kursas1(){
       $ku1 = "Data: %s, Skaicius: %s, Auditorija: %s, (backend kursas)";
       return sprintf($ku1, $this->data, $this->skaicius, $this->auditorija);
   }
}
$f1 = new backend('2000-06-04', '300', '30a');
echo $f1->pa_kursas1() . '<br>';

class frontend extends codeAcademy{
    function pa_kursas2(){
        $ku2 = "Data: %s, Skaicius: %s, Auditorija: %s, (frontend kursas)";
        return sprintf($ku2, $this->data, $this->skaicius, $this->auditorija);
    }
}
$f2 = new frontend('2006-10-10', '50', '3a');
echo $f2->pa_kursas2() . '<br>';

//7.
//Sukurkite PHP skriptą, kuriame aprašykime klasę rndList, kurioje būtų viena savybė ‐ $numbers, kuri bus masyvas, taip pat būtų metodas generate(), kuris sugeneruoja atsitiktini skaičių ir padeda į masyvą sąvybę $numbers. Taip pat sukurkite metodą list(), kuris surikiuoja masyve esančius skaičius ir išveda juos su echo atskiriant vieną nuo kito tarpais.

class rndList{
    public $numbers = [];
    function generate(){
        $g = rand(1, 100);
       $this->numbers[] = $g;
    }
    function list(){
       sort($this->numbers);
        for ($i = 0; $i<count($this->numbers); $i++){
            echo $this->numbers[$i] . ' ';
        }
    }
}
$g1 = new rndList();
$g1->generate();
$g1->generate();
$g1->generate();
$g1->generate();
$g1->generate();
$g1->list();
echo '<br>';

//9.
//Sukurkite PHP skriptą, kuris panaudodamas PDO objektą atliktų prisijungimą prie duomenų bazės ir įvykdytų SQL užklausą visų lentelės ‘asmenys’ duomenų apie 3 vyriausius asmenis gavimui. Rezultatus išveskite HTML lentelės forma.

$h = new PDO('mysql:host=localhost:8889;dbname=nests', 'monimati', '7x10mm96');
$sql = 'select * from asmenys order by asm_data DESC limit 0,3';
$h1 = $h->query($sql);
echo '<table>';
while ($row=$h1->fetch()){
    echo '<tr>';
    echo '<td>' . $row['asm_var'].'</td>>';
    echo '<td>' . $row['asm_lyt'].'</td>>';
    echo '<td>' . $row['asm_data'].'</td>>';
    echo '</tr>';
}
echo '</table>';
$h1->closeCursor();






























