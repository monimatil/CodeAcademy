<?php

 $d = ['BMW', 'Audi', 'Honda'];

 $da = [ 'BMW' => 'Raudona', 'Audi' => 'Balta', 'Honda' => 'Juoda', ]; // raktas - bmw, reiksme - raudona
 echo $d[0] . '<br>'; // naudojam pozicija noredami isvesti elementa
 // ' ' paprasta tekstas
// " " sudetingesnis tekstas su sk ir zenklais
echo $da['BMW'] . '<br>'; // da yra asociatyvinis masyvas todel norint is jo isvesti reiksme reikia naudoti ne pozicija o reiksme

$da1 = [ 'BMW' => ['Raudona', 'Melyna', 'Geltona'], 'Audi' => 'Balta', 'Honda' => 'Juoda', ]; // raktas - bmw, reiksme - raudona
echo $da1['BMW'][0] . ' '. $da1['BMW'][2] .'<br>'; // isveda keles reiksmes
echo implode(' *** ',$da1['BMW']) . '<br>';  // isveda visas pasirinkto rakto reiksmes. glue - kaip atskiriama

$da['Nissan'] = 'Zalia'; //nededam reiksmes i masyva ismeta reiksme
echo json_encode($da) . '<br>'; // ideda prideta rakta ir reiksme i jau turima masyva

unset($da['Honda']);
echo json_encode($da) . '<br>'; // funkcija unset isima pasirinkta rakta su jo reiksme is masyvo

$da = [ 'BMW' => 'Raudona', 'Audi' => 'Balta', 'Honda' => 'Juoda', ];
sort($da);
echo json_encode($da) . '<br>';  // sort rusiuoja. situ budu isveda tik reiksmes todel rusiuoja pagal reiksme

$da = [ 'BMW' => 'Raudona', 'Audi' => 'Balta', 'Honda' => 'Juoda', ];
ksort($da);
echo json_encode($da) . '<br>'; //ksort rusiuoja. pagal rakta

$da = [ 'BMW' => 'Raudona', 'Audi' => 'Balta', 'Honda' => 'Juoda', ];
krsort($da);
echo json_encode($da) . '<br>'; //krsort - rusiuoja pagal rakta, bet juos isvede nuo desines

$a = ['a', 'x', 'z'];
$b = ['c', 'q'];
$c = array_merge($a, $b);     // sujungia du masyvus
print_r($c);                  // isveda masyva su pozicijomis
sort($c);                     // nauja masyva suriusiavo
print_r($c);
echo '<br>' . json_encode($c); // isveda nauja masyvo elementus be poziciju

$a1 = [ 'BMW' => 'Raudona', 'Nissan' => 'Balta', 'Toyota' => 'Juoda', ];
$b1 = [ 'Tesla' => 'Raudona', 'Audi' => 'Balta'];
$c1 = array_merge($a1, $b1);
echo '<br>' . json_encode($c1);
ksort($c1);
echo '<br>' . json_encode($c1);

function test($da, $key){
    if (isset($da[$key])) echo '<br>YRA'; else echo '<br>NERA';
}
test($c1, 'Tesla');  // naudojant funkcija patikrinam ar yra pasirinkta selementas masyve. tesla yra masyve tai isvede yra
test($c1, 'Kia');    // kia tokio elemento nera masyve tai isveda nera

echo '<br>' . $c1['Tesla'] . '<br>'; // tokia funkcija isveda ne pati rakta siuo atveju tesla o reiksme - raudona

//-----
$s = "Labas %s %s. Sveiki atvyke";  // $s - sablonas

echo sprintf($s, 'Jonas', 'Jonaitis'); //sprintf suformuoja sablona pirma ideda labas o paskui vietoj %s iraso pasirinktus argumentus. ju rasai tiek kiek sablone rasei %s


