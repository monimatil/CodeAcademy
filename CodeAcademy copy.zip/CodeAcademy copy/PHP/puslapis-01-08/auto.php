<?php

class auto
{
    public $message = '';
    public $cnn = false;

    function __construct()
    {
        try {
            $this->cnn = new PDO('mysql:host=localhost:8889;dbname=nests', 'monimati', '7x10mm96');
            $this->cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->message = "Prisijungem prie Duomenu Bazes";
        } catch (PDOException $err) {
            $this->message = "Prisijungti pie Duomenu Bazes nepavyko" . $err->getMessage();
        }
    }

    function getList()
    {
        try {
            $a1 = [];
            $sql = 'select * from puslapis ORDER BY auto_gamintojas, auto_modelis';
            $res = $this->cnn->query($sql);
            while ($row = $res->fetch()) {
                $a1[] = [
                    'gamintojas' => $row['auto_gamintojas'],
                    'modelis' => $row['auto_modelis'],
                    'metai' => $row['auto_metai'],
                    'kaina' => $row['auto_kaina'],
                    'nuotrauka' => $row['auto_nuotrauka'],
                    'id' => $row['auto_id'],
                    'mime' => $row['auto_mime'],
                    'pastabos' => $row['auto_pastabos']
                ];
            }
            $this->message = "Info gauta is Duomenu Bazes";
        } catch (PDOException $err) {
            $a1 = false;
            $this->message = "Info gauti is Duomenu Bazes nepavyko" . $err->getMessage();
        }
        return $a1;
    }

    function delete($id)
    {
        $ok = false;
        try {
            $aa = $this->cnn->prepare('delete from puslapis WHERE auto_id = :id');
            $aa->execute([':id' => $id]);
            $this->message = "Automobilis istrinamas is DB";
            $ok = true;

        } catch (PDOException $err) {
            $this->message = "Automobilio is DB istrinti nepavyko" . $err->getMessage();
        }
        return $ok;
    }
    function insert($mas){
        $ok = false;
        try {
            $aaa = $this->cnn->prepare('insert into puslapis (auto_gamintojas, auto_modelis, auto_metai, auto_kaina, auto_pastabos, auto_mime, auto_nuotrauka) values(?, ?, ?, ?, ?, ?, ?)');

            $aaa->bindValue(1, $mas['gamintojas']);
            $aaa->bindValue(2, $mas['modelis']);
            $aaa->bindValue(3, $mas['metai']);
            $aaa->bindValue(4, $mas['kaina']);
            $aaa->bindValue(5, $mas['pastabos']);
            $aaa->bindValue(6, $mas['mime']);
            $aaa->bindValue(7, $mas['nuotrauka'], PDO::PARAM_LOB);
            $aaa->execute();
            $this->message = "Automobilis idetas i DB";
            $ok = true;

        }
        catch (PDOException $err) {
            $this->message = "Automobilio i DB ideti nepavyko" . $err->getMessage();
        }
        return $ok;
    }
    function update($mas){
        $ok = false;
        try {
            $aaa = "update puslapis set auto_gamintojas=?, auto_modelis=?, auto_metai=?, auto_kaina=?, auto_pastabos=?";
            if (isset($mas['nuotrauka'])){
                $aaa.= ",auto_nuotrauka=?, auto_mime=?";
            }
            $aaa.= " where auto_id=?";
            $res = $this->cnn->prepare($aaa);


            $res->bindValue(1, $mas['gamintojas']);
            $res->bindValue(2, $mas['modelis']);
            $res->bindValue(3, $mas['metai']);
            $res->bindValue(4, $mas['kaina']);
            $res->bindValue(5, $mas['pastabos']);
            if (isset($mas['nuotrauka'])){
                $res->bindValue(6, $mas['nuotrauka'], PDO::PARAM_LOB);
                $res->bindValue(7, $mas['mime']);
                $res->bindValue(8, $mas['id']);
            }
            else{
                $res->bindValue(6, $mas['id']);

            }

            $res->execute();
            $this->message = "Automobilio duomenys pakeisti";
            $ok = true;

        }
        catch (PDOException $err) {
            $this->message = "Automobilio duomenu pakeisti nepavyko" . $err->getMessage();
        }
        return $ok;
    }
    function get($id){
        $this->message = "Automobilio duomenu skaitymas is DB";
        try{
            $bbb = $this->cnn->prepare('select * from puslapis WHERE auto_id = :id');
            $bbb->execute([':id' => $id]);
            if ($row = $bbb->fetch()){
                $mas = [
                    'gamintojas' => $row['auto_gamintojas'],
                    'modelis' => $row['auto_modelis'],
                    'metai' => $row['auto_metai'],
                    'kaina' => $row['auto_kaina'],
                    'nuotrauka' => $row['auto_nuotrauka'],
                    'id' => $row['auto_id'],
                    'mime' => $row['auto_mime'],
                    'pastabos' => $row['auto_pastabos']
                ];
                $this->message .= "sekmingas";
            }else $this->message .= "nesekmingas:automobilis nerastas";
        }
        catch (PDOException $err) {
            $this->message .= "nesekmingas" . $err->getMessage();
            $mas = false;
        }
        return $mas;
    }
  
}


/*
$a = new auto();
var_export($a);
echo '<br>';
$b = $a->getList();
var_dump($b);
echo '<br>';
*/
