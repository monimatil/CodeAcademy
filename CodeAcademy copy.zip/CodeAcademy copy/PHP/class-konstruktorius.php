<?php

class darbuotojas {
    public $vardas;
    public $pavarde;
    public $alga;

    function __construct($vard, $pav, $alg){
        $this->vardas = $vard;
        $this->pavarde = $pav;
        $this->alga = $alg;
    }
    function info(){
        $s = 'Vardas: %s, Pavarde: %s, Alga: %s $';
        return sprintf($s, $this->vardas, $this->pavarde, $this->alga);
    }
    function vardas_pavarde($skyriklis){
        return $this->vardas . $skyriklis . $this->pavarde;
    }
}

$d = new darbuotojas('Jonas', 'Jonaitis', 1500);  // egzemplioriaus kurimas
var_export($d);
echo '<br>';

echo $d->info() . '<br>';

echo $d->vardas_pavarde(' ') . '<br>';    // tarp vardo ir pavardes idetas skyriklis siuo atveju tarpas

echo $d->vardas_pavarde(' * ') . '<br>';  // tarp vardo ir pavardes idetas skyriklis siuo atveju tarpas * tarpas

