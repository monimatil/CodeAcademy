<?php
//1. kintamieji a ir b
$a = 20;
$b = 40;

//c kintamasis apskaiciuoti kintamuju saknu vidurkis
$c = (sqrt($a) + sqrt($b)) / 2;

//isvedam atsakyma
echo $c;
echo '<br>';

//2. sukuriam asociatyvuni masyva(masyvas jau su priskirtom reiksmem)
$d = [
    'Marke' => 'Tesla',
    'Modelis' => 'S',
    'Metai' => '2017',
    'Spalva' => 'Balta',
    'Galia' => '200AG'
];

//isvedam masyva
var_export($d);
echo '<br>';

//3.
function param($e, $f, $g){
    $h = $e + $f + $g;
    return $h;
}

echo param(8, 3, 4);
echo '<br>';

//4.

$mas = ['jonas', 'tomas','antanas', 'lukas', 'petras'];
// i prisilyginam nuliui kad is masyvo imtu nuo 0 elemento
$i = 0;
foreach ($mas as $value){
    //imam masyva ir lauztiniuose skliaustuose parasom i++ tam kad kiekviena karta sukant cikla imtu kita masyvo elementa ir ji keistu kad visos raides butu didziosios
   $mas[$i++] = strtoupper($value);
}
// masyvo isvedimas
var_export($mas);
echo '<br>';

//5.
$amas = [
    'first' => 'pirmas',
    'second' => 'antras',
    'third' => 'trecias',
    'forth' => 'ketvirtas',
    'fifth' => 'penktas'
];

foreach ($amas as $key=>$value){
    $amas[$key] = ucfirst(strtolower($value));
}
var_export($amas) . '<br>';

echo '<br>';

