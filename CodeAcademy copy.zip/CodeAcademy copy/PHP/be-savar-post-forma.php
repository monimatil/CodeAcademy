<?php

session_start();

if(!isset($_SESSION['sesija']));

$_SESSION['sesija'] = $_POST;

echo $_POST['impav'] . '<hr>';
echo $_POST['imkod'] . '<hr>';
echo $_POST['ktip'] . '<hr>';

echo '<a href="fr-savar-post-forma.html">Grizti i forma</a><br>';


print_r($_POST);

//nenusiuncia i php faila nes yra echo. formoj pasirinku lieka tam paciam psl
//header('Location: http://localhost:8888/PHP/fr-savar-post-forma.html');

//kad pasirinktu pagal metus, des rasom kad grupuotu metus nuo maziausiu iki didziausiu
//limit atrenka tik tiek kiek parasom
//select * from auto ORDER BY aut_metai desc LIMIT 0,2

//atrenka tik tas imones kuriu tipo paparasem
//SELECT * FROM imones WHERE kli_tip='Auksinis'
