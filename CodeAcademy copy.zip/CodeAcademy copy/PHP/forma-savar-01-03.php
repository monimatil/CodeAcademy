<?php

session_start();

if(!isset($_SESSION['sesija']));

$_SESSION['sesija'] = $_GET;

header('location: form-savar-01-03.html');


$a = fopen('forma-01-03.txt', 'a');

$s = '';
foreach ($_GET as $key => $value){
    $s .= ' '.$key.'=>'.$value;
}
fwrite($a, $s);
fclose($a);


//echo $_GET['vardas'] . '<hr>';
//echo $_GET['pavarde'] . '<hr>';
//echo $_GET['maistas'] . '<hr>';

//echo '<a href="form-savar-01-03.html">Grizti i forma</a><br>';

//print_r($_GET);

