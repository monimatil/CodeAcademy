<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<?php
$a = new handlerForm();
?>
<!--jeigu neparasom method vistiek bus get-->
<form method="post" action="forms-post.php">
<label>Vardas: </label><input name="vardas" type="text" value="<?php echo $a->getVariable("Vardas")?>"><br>
<label>Pavarde: </label><input name="pavarde" type="text" value="<?php echo $a->getVariable("pavarde")?>"><br>
<label>Slaptazodis: </label><input name="slaptazodis" type="password"><br>
<input type="submit" value="Vykdyti">
</form>

<?php

//var_dump($_GET);
//echo json_encode($_GET);

class handlerForm {
    public $text;
    function __construct(){
        if (count($_POST)>0){
            $this->text = '';
            foreach ($_POST as $key => $value){
                $this->text .=$key . '=' . $value . '<br>';
            }
        }
    }
    function toFile(){
        $f = fopen("failai/forms-post-parms.txt", 'w') or die("Unable to open file!");
        fwrite($f, $this->text);
        fclose($f);
    }
    function fromFile(){
        $f = fopen("failai/forms-post-parms.txt", 'w') or die("Unable to open file!");
        $s = fread($f, filesize("failai/forms-post-parms.txt"));
        fclose($f);
        return $s;
    }
    function getVariable($name){
        if (isset($_POST[$name])) return $_POST[$name];
        else return '';
    }
}

$a = new handlerForm();
$a->toFile();
$x = $a->fromFile();
echo $x;

?>
</body>
</html>
