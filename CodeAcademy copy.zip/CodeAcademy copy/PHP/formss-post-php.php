<?php

/*  sita masyva sukuria PHP automatiskai pagal webe uzpildyta forma
$_POST = [
        'vardas' => 'jonas',
    'pavarde' => 'jonaitis',
    'Maistas' => 'mesa',

];
*/
var_export($_POST); echo '<hr>';  // isveda masyva su reiksmem

echo $_POST['vardas'] . '<hr>';    //isveda tik varda
echo $_POST['pavarde'] . '<hr>';   //isveda tik pavarde
echo $_POST['Maistas'] . '<hr>';   //isveda tik pasirinkta maista

$s = '';
foreach ($_POST as $key => $value);{    // jei norim pereiti per visas masyvo reiksmes
    echo $key. ': ' . $value. '<br>';
}

echo '<a href="formss-post-html.html">Atgal</a>';  // atgal i progtama