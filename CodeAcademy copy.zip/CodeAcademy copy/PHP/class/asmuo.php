<?php


class asmuo{
    public $vardas;
    public $pavarde;
    public $amzius;
    function __construct($v, $p, $a){
        $this->vardas = $v;
        $this->pavarde = $p;
        $this->amzius = $a;
    }
}