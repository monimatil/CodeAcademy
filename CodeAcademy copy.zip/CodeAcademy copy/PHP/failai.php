<?php

$myfile = fopen("failas.txt", "w");  //atidarymas
$txt = "Labas rytas";
fwrite($myfile, $txt);  //irasymas
fclose($myfile);        //uzdarymas

echo 'irasyti<br>';

$myfile = fopen("failas.txt", "w");  //atidarymas
$txt = "2017";
fwrite($myfile, $txt);  //irasymas
fclose($myfile);        //uzdarymas

echo 'papildyta<br>';

if (!file_exists('failai2')){
    mkdir('failai2');
    echo 'dir-as sukurtas<br>';
}
rmdir('failai2');
echo 'dir-as pasalintas<br>';

copy('failai.txt', 'failai/failas.txt');
echo 'failas nukopijuotas<br>';

unlink('failai/failas.txt');
echo 'failas pasalintas<br>';

$a = scandir('.');
//var_export($a);

foreach ($a as $fn) {
    echo $fn. '<br>';

}