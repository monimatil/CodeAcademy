<?php
//1.
//Sukurkite PHP skriptą, kuriame būtų aprašyti trys kintamieji ir ekrane būtų išvestas tų kintamųjų kvadratų vidurkis.

$a = 5;
$a1 = 6;
$a2= 7;

echo (($a**2) + ($a1**2) + ($a2**2))/ 3;
echo '<br>';
//2.
//Sukurkite PHP skriptą, kuriame būtų aprašytas masyvas, aprašantis tris codeAcademy kursus, kurių kiekvienas yra aprašytas asociatyviniu masyvu naudojant raktus. Asociatyviniuose  masyvuose turi būti laukeliai: kurso pavadinimas, mokinių skaičius, kursų pradžios data.

$b = [
    ['Pirmas', '12', '2018-01-02'],
    ['Antras', '10', '2017-12-20'],
    ['Trecias', '13', '2018-02-02']
];

var_dump($b);
echo '<br>';

//3.
//Sukurkite PHP skriptą, kuriame būtų aprašyta funkcija, kuriai padavus 5 parametrus ‐ skaičius, funkcija turi paskaičiuoti aritmenitinį vidurkį, ištraukti šaknį ir padauginti iš 10. Rezultatą gražinti. Iškviesti funkciją perduodant 5 parametrus (skaičius) ir parodyti rezultatą.

function skaiciai($c1, $c2, $c3, $c4, $c5){
    $c = sqrt($c1 + $c2 + $c3 + $c4 + $c5) * 10;
    return $c;
}
echo skaiciai(3, 4, 5, 6, 7) . '<br>';

//4.
//Sukurkite PHP skriptą, kuriame būtų aprašytas tekstas sudarytas iš žodžių. Suskaidykite tekstą į žodžius ir sukelkite į masyvą. Panaudodami while ciklą ‐ pakeiskite visus masyvo elementus ‐ paversdami tekstą didžiosiomis raidemis, gale teksto prijunkite taško simbolį '.'. Sujunkite visus masyvo elementus į vieną teksto eilutę sujungdami juos kableliais ','.


$d = "Laba diena kiek valandu";
$d1 = explode(' ', $d);

$i = 0;

while ($i >count($d1[$i])){
    $d1[$i] = strtoupper($d[$i]) . '.';
    $i++;
}
echo implode(',', $d1) . '<br>';

//5.
//Sukurkite PHP skriptą, kuriame būtų aprašyta klasė “universitetas”, kuri turi savybes ‐ pavadinimas, miestas, studentai. Sukurkite standartinį klasės __construct metodą, kuriam perdavus tris parametrus ‐ pavadinimas, miestas, studentai ‐ perduotus parametrus padėtų į savo savybes.
//6.
//Panaudodami prieš tai sukurtą klasę universitetas, sukurkite klases ktu ir vu, kurios paveldi universitetas klasę. universitetas klasę papildykite metodu “info”, kuris išvestų suformatuotą eilutę “pavadinimas, miestais, studentai”. ktu klasėje perrašykite metodą info, pakeisdami išvedamą eilutę į “pavadinimas, miestais, studentai (KTU)”. KTU ‐ tiesiog paprastas žodis. vu klasėje perrašykite metodą info, pakeisdami išvedamą eilutę į “pavadinimas, miestais, studentai (VU)”. VU ‐ tiesiog paprastas žodis. Patkrinkite visų trijų klasių metodo “info” veikimą.

class universitetas{
    public $pavadinimas;
    public $miestas;
    public $studentai;
    function __construct($pav, $mie, $stud){
        $this->pavadinimas = $pav;
        $this->miestas = $mie;
        $this->studentai = $stud;
    }
    function info(){
        $sablonas = "Pavadinimas: %s, Miestas: %s, studentai: %s";
        return sprintf($sablonas, $this->pavadinimas, $this->miestas, $this->studentai);
    }
}
$e1 = new universitetas('VDA', 'Vilnius', '200');
echo $e1->info() . '<br>';

class ktu extends universitetas{
    function infoKtu(){
        $sablonas1 = "Pavadinimas: %s, Miestas: %s, studentai: %s (KTU)";
        return sprintf($sablonas1, $this->pavadinimas, $this->miestas, $this->studentai);
    }
}
$e2 = new ktu('KTU', 'Kaunas', '300');
echo $e2->infoKtu() . '<br>';

class vu extends universitetas{
    function infoVu(){
        $sablonas2 = "Pavadinimas: %s, Miestas: %s, studentai: %s (VU)";
        return sprintf($sablonas2, $this->pavadinimas, $this->miestas, $this->studentai);
    }
}
$e3 = new vu('VU', 'Vilnius', '100');
echo $e3->infoVu() . '<br>';


//7.
//Sukurkite PHP skriptą, kuriame aprašykite klasę loto, kurioje būtų viena savybė ‐ $table, kuri bus dvimatis masyvas, taip pat būtų metodas generate(), kuris sugeneruoja 5 x 5 atsitiktinių skaičių dvimatį masyvą (min skaičius = 1, max skaičius = 75). Sukurkite metodą get(),kuris išveda sugeneruotą masyvą 5 x 5 HTML lentele. Pademonstruokite veikimą.

class loto{
    public $table = [];
    function generate(){
        for ($i = 0; $i<5; $i++){
            for ($j = 0; $j<5; $j++){
                $this->table[$i][$j]= rand(1,75);
            }
        }
    }
    function get(){
       echo '<table>';
        for ($i = 0; $i<5; $i++){
            echo '<tr>';
            for ($j = 0; $j<5; $j++) {
                echo '<td>'. $this->table[$i][$j] .'</td>';
            }
            echo '</tr>';
        }
       echo '</table>';
    }
}
$f1 = new loto();
$f1->generate();
$f1->get();
echo '<br>';

//9.
//Sukurkite PHP skriptą, kuriame aprašykite klasę lentele, kurioje būtų viena savybė ‐ $table, kuri bus dvimatis masyvas, taip pat būtų metodas add, kurio parametras yra 3 skaičių masyvas. Patalpinti gautą masyvą į savybės %table masyvą. Sukurkite metodą get(),kuris paskaičiuoja kiekvienoje lentelės eilutėje esančių elemntų vidurkį ir jų patalpina į eilutės pabaigą. Išvesti savybės $table masyvą HTML lentele. Pademonstruokite veikimą.


class lentele{
    public $table1 = [];
    function add1($g1){
        $g2 = 0;
        foreach ($g1 as $skc){
            $g2 += $skc;
        }
        $g1[] = $g2 / count($g1);
        $this->table1[] = $g1;
    }
    function get1(){
        echo '<table>';
        for ($i1 = 0; $i1<count($this->table1); $i1++){
            echo '<tr>';
            for ($j1 = 0; $j1<count($this->table1[$i1]); $j1++){
                echo '<td>' .$this->table1[$i1][$j1]. '</td>';
            }
            echo '<tr>';
        }
        echo '</table>';
    }
}
$g = new lentele();
$g->add1([1,28,3]);
$g->add1([3,44,5]);
$g->add1([6,74,8]);
$g->get1();

//10.
//Sukurkite klasę diagnostika. Klasės savybė - $duomenys - asociatyvimis masyvas, kuriame yra diagnostikos pranesimai apie klaidas: raktas => tekstas (angliškas). Padaryti funkcija, kuri pagal kodą (funkcijos parametras) gražina klaidos pranešimo tekstą. Sukurti lituanizuotą diagnostikos klasę diagnostika_lt, kuri paveldi klasę diagonostika ir turi kitą diagnostikos pranešimų masyvą (pakeičiantį originalą), kur kodai yra tie patys, o tekstai - lietuviški. Išbandyti abi klases kreipiantis į funkciją tuo pačiu kodu. Jeigu kodo masyve nėra, tai reikia gražinti pranešimą "Code not found" ("Kodas nerastas")

class diagnostika{
    public $duomenys = ['raktas1' =>'error1', 'raktas2' =>'error2','raktas3' =>'error3'];
    function param($duom){
        if (isset($this->duomenys[$duom])){
            return $this->duomenys[$duom];
        }
    }
}
$par = new diagnostika();
echo $par->param('raktas3') . '<br>';


class diagnostika_lt extends diagnostika {
    public $duomenys = ['raktas1' =>'klaida1', 'raktas2' =>'klaida2','raktas3' =>'klaida3'];
    function param($duom){
        if (isset($this->duomenys[$duom])){
            return $this->duomenys[$duom];
        }
    }
}
$par = new diagnostika_lt();
echo $par->param('raktas3') . '<br>';



































