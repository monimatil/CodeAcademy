<?php

class personalas {
    public $darbuotojai;
    function persona($vardas, $pavarde, $lytis){
        if (!isset($this->darbuotojai)) $this->darbuotojai=[];
        $this->darbuotojai[] = [
            'vardas' => $vardas,
            'pavarde' => $pavarde,
            'lytis' => $lytis
        ];
    }
    function kiekMoteru(){
        $mot = 0;
        for ($i=0; $i<count($this->darbuotojai); $i++){
            //for naudojama tam kad funkcijoj darytu cikla
            //su if reiksme prisilygine M ieskom kiek moteru yra sarase. ir sarase radus moteri pr mot=0 pridedam 1 ir funkcija kartojam dar karta kol iseisim visus masyva esancius darbuotojus.
            if ($this->darbuotojai[$i]['lytis'] == 'M') $mot += 1;
        }
        return $mot;
    }
    function kiekVyru(){
        $vyr = 0;
        for ($i=0; $i<count($this->darbuotojai); $i++) {
            if ($this->darbuotojai[$i]['lytis'] == 'V') $vyr += 1;

        }
        return $vyr;
    }


    }

$per = new personalas();
$per->persona('Jonas', 'Jonaitis', 'V');
$per->persona('Ana', 'Anaite', 'M');
$per->persona('Petras', 'Petraitis', 'V');

echo $per->kiekMoteru() . '<br>';

echo $per->kiekVyru() . '<br>';
