<?php

class automobiliai{
    public $sarasas;
    function automobilis($gamintojas, $modelis, $kuras, $sanaudos){
        if (!isset($this->sarasas)) $this->sarasas = [];
        $this->sarasas[] = [
          'gamintojas' => $gamintojas,
          'modelis' => $modelis,
          'kuras' => $kuras,
          'sanaudos' => $sanaudos
        ];
    }
    function kurovidurkisDyzelis(){
        $summ = 0;
        $kiek = 0;
        for ($i = 0; $i<count($this->sarasas); $i++){
            //if kuro tipa prisilyginam dyzeliui
            //kieki1 tai kiek masinu yra kuriu kuro tipas yra benzinas ir kadangi kiekis yra lygus 0 prie jo pridedam vis po viena einant cikle patikrinant visas masinas
            //suma prisilyginam tam kad imtu sanaudas
            if ($this->sarasas[$i]['kuras'] == 'Dyzelis'){
                $kiek += 1;
                $summ += $this->sarasas[$i]['sanaudos'];
            };
        }
        return $summ / $kiek;  // padalina visu masinu sanaudu suma is kiekio


    }

    function kurovidurkisBenzinas()
    {
        $sum1 = 0;
        $kiek1 = 0;
        for ($i = 0; $i < count($this->sarasas); $i++) {
            //if kuro tipa prisilyginam bendzinui
            //kieki1 tai kiek masinu yra kuriu kuro tipas yra benzinas ir kadangi kiekis yra lygus 0 prie jo pridedam vis po viena einant cikle patikrinant visas masinas
            //suma prisilyginam tam kad imtu sanaudas
            if ($this->sarasas[$i]['kuras'] == 'Benzinas') {
                $kiek1 += 1;
                $sum1 += $this->sarasas[$i]['sanaudos'];
            };
        }
        return $sum1 / $kiek1; // padalina visu masinu sanaudu suma is kiekio
    }
}

$a = new automobiliai();
$a->automobilis('Bmw', 'X5', 'Benzinas', 10);
$a->automobilis('Tesla', 'S', 'Dyzelis', 20);
$a->automobilis('Audi', 'A6', 'Benzinas', 7);
$a->automobilis('Honda', 'Civic', 'Dyzelis', 5);
//1.
echo $a->kurovidurkisDyzelis() . '<br>';
//2.
echo $a->kurovidurkisBenzinas();





