
<?php
function arg($d, $e){
    $f = $d - $e;
    return $f;
}
echo arg(6, 2);