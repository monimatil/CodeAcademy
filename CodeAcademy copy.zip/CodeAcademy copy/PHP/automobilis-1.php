<?php

include 'class/automobilis.php';
include 'class/servisas.php';

$automobilis = [];
$automobilis [] = new servisas('Tesla', 'X', '2017');
$automobilis [] = new servisas('Bmw', 'G3', '2015');
$automobilis [] = new servisas('Audi', 'A5', '2000');

foreach ($automobilis as $au){
    echo $au->info() . '<br>';
}

