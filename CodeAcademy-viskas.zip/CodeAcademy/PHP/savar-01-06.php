<?php

//1.1
//Sukurkite PHP skriptą, kuriame būtų aprašyti du kintamieji ir ekrane būtų išvestas tų kintamųjų skirtumo šaknis.

$a1 = 8;
$a2 = 6;

echo sqrt($a1 - $a2) . '<br>';

//1.2
//Sukurkite PHP skriptą, kuriame būtų aprašyti trys kintamieji ir ekrane būtų išvestas tų kintamųjų kvadratų vidurkis.

$b1 = 7;
$b2 = 6;
$b3 = 5;

echo ($b1**2 + $b2**2 + $b3**2)/3 . '<br>';

//1.3
////Sukurkite PHP skriptą, kuriame būtų aprašyti du kintamieji. Sudėkite juos, sumą padauginkite iš PI reikšmės. Išveskite rezultatą ekrane.

$c1 = 8;
$c2 = 5;

echo ($c1 + $c2)*pi() . '<br>';

//2.1
//Sukurkite PHP skriptą, kuriame būtų aprašytas masyvas, aprašantis tris automobilius, kurių kiekvienas yra aprašytas asociatyviniu masyvu naudojant raktus. Asociatyviniuose  masyvuose turi būti laukeliai: gamintojas, modelis, pagaminimo metai, galingumas.

$d = [
    ['Tesla', 'S', '2017', '300AG'],
    ['BMW', 'X6', '2016', '200AG'],
    ['Audi', 'A6', '2015', '100AG'],
];

var_export($d);
echo '<br>';

//2.2
////Sukurkite PHP skriptą, kuriame būtų aprašytas masyvas, aprašantis tris codeAcademy kursus, kurių kiekvienas yra aprašytas asociatyviniu masyvu naudojant raktus. Asociatyviniuose  masyvuose turi būti laukeliai: kurso pavadinimas, mokinių skaičius, kursų pradžios data.

$d1 = [
    ['Pirmas', '2017', '2001-02-03'],
    ['Antras', '2016', '2007-04-03'],
    ['Trecias', '2015', '2006-02-30'],
];

var_export($d1);
echo '<br>';

//2.3
////Sukurkite PHP skriptą, kuriame būtų aprašytas taksi automobilio asociatyvinis masyvas, kurio raktai yra: gamintojas, modelis, metai, vairuotojai. Vairuotojai taip pat turi būti asociatyvinis masyvas, kurio raktai: vardas, pavarde, stazas.

$d2 = [
    ['gamintojas' => 'Tesla'],
    ['modelis' => 'S'],
    ['vairuotojas' =>[
        ['vardas' => 'Jonas'],
        ['pavarde' => 'Jonaitis'],
        ['stazas' => '2m']
    ]]
];

var_export($d2);
echo '<br>';

//3.1
//Sukurkite PHP skriptą, kuriame būtų aprašyta funkcija, kuriai padavus tris parametrus ‐ tekstus, funkcija turi grąžinti rezultatą ‐ formatuota tekstą. Teksto formatavimui naudokite šabloną.

function pirma($e1, $e2, $e3){
    $pirmas_sablonas = 'Pirmas : %s, Antras: %s, Trecias: %s';
    return sprintf($pirmas_sablonas, $e1, $e2, $e3);
}
echo pirma('First', 'Second', 'Third') . '<br>';

//3.2
//Sukurkite PHP skriptą, kuriame būtų aprašyta funkcija, kuriai padavus 5 parametrus ‐ skaičius, funkcija turi paskaičiuoti aritmenitinį vidurkį, ištraukti šaknį ir padauginti iš 10. Rezultatą gražinti. Iškviesti funkciją perduodant 5 parametrus (skaičius) ir parodyti rezultatą.

function antra($f1, $f2, $f3, $f4, $f5){
    return sqrt(($f1 + $f2 + $f3 + $f4 +$f5) / 5) * 10;
}

echo antra('2', '3', '4', '5', '6');

//3.3
//Sukurkite PHP skriptą, kuriame būtų aprašyta funkcija, su 3 parametrais: minimalus skaicius, maksimalus skaicius, kiek atsitiktinių skaiciu sugeneruoti. Funkcija gražinti atsitiktinių skaičių masyvą. Pademonstruoti funkcijos veikimą.

function trecia($min, $max, $kiek){
    $g = [];
    for ($i = 0; $i<$kiek; $i++){
        $g[$i] = rand($min, $max);
    }
    return $g;
}
var_export(trecia('2', '9', '4'));
echo '<br>';


//4.1
//Sukurkite PHP skriptą, kuriame būtų aprašytas tekstas sudarytas iš žodžių. Suskaidykite tekstą į žodžius ir sukelkite į masyvą. Panaudodami for ciklą ‐ pakeiskite visus masyvo elementus ‐ paversdami tekstą mažosiomis raidėmis, pirmą raidę - didžiąja. Sujunkite visus masyvo elementus į vieną teksto eilutę sujungdami juos vertikaliais '|' brūšniais.

$h = 'pirmas antras trecias ketvirtas';
$h1 = explode(' ', $h);

for ($i = 0; $i<count($h1); $i++){
    $h1[$i] = ucfirst(strtolower($h1[$i]));
}
echo implode(' | ', $h1) . '<br>';

//4.2
//Sukurkite PHP skriptą, kuriame būtų aprašytas tekstas sudarytas iš žodžių. Suskaidykite tekstą į žodžius ir sukelkite į masyvą. Panaudodami while ciklą ‐ pakeiskite visus masyvo elementus ‐ paversdami tekstą didžiosiomis raidemis, gale teksto prijunkite taško simbolį '.'. Sujunkite visus masyvo elementus į vieną teksto eilutę sujungdami juos kableliais ','.

$hh = "penktas sestas septintas astuntas";
$h2 = explode(' ', $hh);

$i = 0;
while ($i<count($h2)){
    $h2[$i] = strtoupper($h2[$i]);
    $i++;
}
echo implode(',', $h2). '.' .'<br>';

//4.3
//Sukurkite PHP skriptą, kuriame būtų aprašytas vienmatis skaičių masyvas. Masyvo kas antro elemento reikšmę cikle programiškai pakeiskite į 0.

$j = [2, 3, 4, 5, 6];

for ($i = 0; $i<count($j); $i++){
    if ($j[$i] % 2 !==0){
        $j[$i] = 0;
    }
}
var_export($j);
echo '<br>';

//5.1.1
//Sukurkite PHP skriptą, kuriame būtų aprašyta klasė “codeAcademy”, kuri turi savybes ‐ data, skaicius, auditorija. Sukurkite standartinį klasės __construct metodą, kuriam perdavus tris parametrus ‐ data, skaicius, auditorija ‐ perduotus parametrus padėtų į savo savybes.
//5.1.2
//Panaudodami prieš tai sukurtą klasę codeAcademy, sukurkite klases backend ir frontend, kurios paveldi codeAcademy klasę. codeAcademy klasę papildykite metodu “kursas”, kuris išvestų suformatuotą eilutę “data, skaicius, auditorija”. backend klasėje perrašykite metodą duomenys, pakeisdami išvedamą eilutę į “data, skaicius, auditorija (backend kursas)”. backend kursas ‐ tiesiog paprastas žodis. frontend klasėje perrašykite metodą duomenys, pakeisdami išvedamą eilutę į “data, skaicius, auditorija (frontend kursas)”. frontend kursas ‐ tiesiog paprastas žodis. Patkrinkite visų trijų klasių metodo “kursas” veikimą.

class codeAcademy{
    public $data;
    public $skaicius;
    public $auditorija;
    function __construct($dat, $skc, $aud){
        $this->data = $dat;
        $this->skaicius = $skc;
        $this->auditorija = $aud;
    }
    function kursas(){
        $s1 = 'Data: %s, Skaicius: %s, Auditorija: %s';
        return sprintf($s1, $this->data, $this->skaicius, $this->auditorija);
    }
}
$k = new codeAcademy('2001-02-03', '300', '12a');
echo $k->kursas() . '<br>';

class backend extends codeAcademy{
    function kursasBE(){
        $s2 = 'Data: %s, Skaicius: %s, Auditorija: %s (backend)';
        return sprintf($s2, $this->data, $this->skaicius, $this->auditorija);
    }
}
$k1 = new backend('2001-05-20', '140', '12a');
echo $k1->kursasBE() . '<br>';


class frontend extends codeAcademy{
    function kursasFE(){
        $s3 = 'Data: %s, Skaicius: %s, Auditorija: %s (frontend)';
        return sprintf($s3, $this->data, $this->skaicius, $this->auditorija);
    }
}
$k2 = new frontend('2001-10-30', '160', '12a');
echo $k2->kursasFE() . '<br>';

//5.2.1
//Sukurkite PHP skriptą, kuriame būtų aprašyta klasė “universitetas”, kuri turi savybes ‐ pavadinimas, miestas, studentai. Sukurkite standartinį klasės __construct metodą, kuriam perdavus tris parametrus ‐ pavadinimas, miestas, studentai ‐ perduotus parametrus padėtų į savo savybes.
//5.2.2
//Panaudodami prieš tai sukurtą klasę universitetas, sukurkite klases ktu ir vu, kurios paveldi universitetas klasę. universitetas klasę papildykite metodu “info”, kuris išvestų suformatuotą eilutę “pavadinimas, miestais, studentai”. ktu klasėje perrašykite metodą info, pakeisdami išvedamą eilutę į “pavadinimas, miestais, studentai (KTU)”. KTU ‐ tiesiog paprastas žodis. vu klasėje perrašykite metodą info, pakeisdami išvedamą eilutę į “pavadinimas, miestais, studentai (VU)”. VU ‐ tiesiog paprastas žodis. Patkrinkite visų trijų klasių metodo “info” veikimą.

class universitetas {
    public $pavadinimas;
    public $miestas;
    public $studentai;
    function __construct($pa, $mie, $stud){
        $this->pavadinimas = $pa;
        $this->miestas = $mie;
        $this->studentai = $stud;
    }
    function info(){
        $ss = 'Pavadinimas: %s, Miestas: %s, Studentai: %s ';
        return sprintf($ss, $this->pavadinimas, $this->miestas, $this->studentai);
    }
}
$l = new universitetas('VDU', 'Kaunas', '2000');
echo $l->info() . '<br>';

class ktu extends universitetas{
    function infoKtu(){
        $ss1 = 'Pavadinimas: %s, Miestas: %s, Studentai: %s (KTU)';
        return sprintf($ss1, $this->pavadinimas, $this->miestas, $this->studentai);
    }
}
$l1 = new ktu('KTU', 'Kaunas', '20000');
echo $l1->infoKtu() . '<br>';


class vu extends universitetas{
    function infoVu(){
        $ss2 = 'Pavadinimas: %s, Miestas: %s, Studentai: %s (VU) ';
        return sprintf($ss2, $this->pavadinimas, $this->miestas, $this->studentai);
    }
}
$l2 = new vu('VU', 'Vilnius', '200');
echo $l2->infoVu() . '<br>';

//5.3.1
//Sukurkite PHP skriptą, kuriame būtų aprašyta klasė “dviratis”, kuri turi savybes ‐ pavadinimas, kaina. Sukurkite standartinį klasės __construct metodą, kuriam perdavus du parametrus ‐ pavadinimas, kaina ‐ perduotus parametrus padėtų į savo savybes. Panaudodami prieš tai sukurtą klasę dviratis, sukurkite klases moteriskas ir vyriskas, kurios paveldi dviratis klasę. dviratis klasę papildykite metodu “info”, kuris išvestų suformatuotą eilutę “pavadinimas, kaina”. moteriskas klasėje perrašykite metodą info, pakeisdami išvedamą eilutę į “pavadinimas, kaina: moteriskas”. moteriskas ‐ tiesiog paprastas žodis. vyriskas klasėje perrašykite metodą info, pakeisdami išvedamą eilutę į “pavadinimas, kaina: vyriskas”. vyriskas ‐ tiesiog paprastas žodis. Patkrinkite visų trijų klasių metodo “info” veikimą.

class dviratis{
    public $pavadinimas1;
    public $kaina1;
    function __construct($pav1, $kai1){
        $this->pavadinimas1 = $pav1;
        $this->kaina1 = $kai1;
    }
    function d_info(){
        $sss = 'Pavadinimas: %s, Kaina: %s';
        return sprintf($sss, $this->pavadinimas1, $this->kaina1);
    }
}
$m = new dviratis('Pirmas', '2000');
echo $m->d_info() . '<br>';

class d_moteriskas extends dviratis{
    function d_info_mot(){
        $sss2 = 'Pavadinimas: %s, Kaina: %s (moteriskas)';
        return sprintf($sss2, $this->pavadinimas1, $this->kaina1);
    }
}
$m1 = new d_moteriskas('Antras', '200');
echo $m1->d_info_mot() . '<br>';

class d_vyriskas extends dviratis{
    function d_info_vyr(){
        $sss3 = 'Pavadinimas: %s, Kaina: %s (vyriskas)';
        return sprintf($sss3, $this->pavadinimas1, $this->kaina1);
    }
}
$m2 = new d_vyriskas('Trecias', '20000');
echo $m2->d_info_vyr() . '<br>';

//6.1
//Sukurkite PHP skriptą, kuriame aprašykime klasę rndList, kurioje būtų viena savybė ‐ $numbers, kuri bus masyvas, taip pat būtų metodas generate(), kuris sugeneruoja atsitiktini skaičių ir padeda į masyvą sąvybę $numbers. Taip pat sukurkite metodą list(), kuris surikiuoja masyve esančius skaičius ir išveda juos su echo atskiriant vieną nuo kito tarpais.

class rndList{
    public $numbers = [];
    function generate(){
        $n1 = rand(1, 50);
        $this->numbers[] = $n1;
    }
    function list(){
        sort($this->numbers);
        for ($i = 0; $i<count($this->numbers); $i++){
            echo $this->numbers[$i] . ' ';
        }
    }
}
$n = new rndList();
$n->generate();
$n->generate();
$n->generate();
$n->generate();
$n->generate();
$n->list();
echo '<br>';

//6.2
//Sukurkite PHP skriptą, kuriame aprašykite klasę loto, kurioje būtų viena savybė ‐ $table, kuri bus dvimatis masyvas, taip pat būtų metodas generate(), kuris sugeneruoja 5 x 5 atsitiktinių skaičių dvimatį masyvą (min skaičius = 1, max skaičius = 75). Sukurkite metodą get(),kuris išveda sugeneruotą masyvą 5 x 5 HTML lentele. Pademonstruokite veikimą.

class loto{
    public $table;
    function l_generate(){
        for ($i1 = 0; $i1<5; $i1++){
            for ($i2 = 0; $i2<5; $i2++){
                $this->table[$i1][$i2] = rand(1, 75);
            }
        }
    }
    function get(){
        echo '<table>';
        for ($i1 = 0; $i1<4; $i1++){
            echo '<tr>';
            for ($i2 = 0; $i2<5; $i2++){
                echo '<td>' . $this->table[$i1][$i2]. '</td>';
            }
            echo '</tr>';
        }
        echo '</table>';
    }
}
$o = new loto();
$o->l_generate();
$o->get();
echo '<br>';

//6.3
//Sukurkite PHP skriptą, kuriame aprašykime klasę numberList, kurioje būtų viena savybė ‐ $numbers, kuri bus masyvas, taip pat būtų metodas add($number), kuris prideda naują skaičių į masyvą sąvybę $numbers. Sukurkite metodą delMin(), kuris pašalina mažiausią masyve sąvybėje esantį skaičių. sukurkite funkciją getInfo(), kuris išveda skaičius esančius savybėje.

class numberList{
    public $nbrs = [];
    function prideti($nbr){
        $this->nbrs[] = $nbr;
        return $nbr;
    }
    function delMin(){
        $min = $this->nbrs[0];
        $min_i = 0;
        for ($i = 0; $i<count($this->nbrs); $i++){
            if ($this->nbrs[$i] < $min) {
                $min = $this->nbrs[$i];
                $min_i = $i;
            }
        }
        unset($this->nbrs[$min_i]);
    }
    function getInfo(){
        foreach ($this->nbrs as $numbr){
            echo $numbr . ' ' .'<br>';
        }
    }
}
$p = new numberList();
$p->prideti(3);
$p->prideti(4);
$p->prideti(5);
$p->prideti(6);
$p->prideti(7);
$p->getInfo();
echo '<br>';
$p->delMin();
$p->getInfo();
echo '<br>';

//7.1
//Sukurkite PHP skriptą, kuriame aprašykite klasę lentele, kurioje būtų viena savybė ‐ $table, kuri bus dvimatis masyvas, taip pat būtų metodas add, kurio parametras yra 3 skaičių masyvas. Patalpinti gautą masyvą į savybės %table masyvą. Sukurkite metodą get(),kuris paskaičiuoja kiekvienoje lentelės eilutėje esančių elemntų vidurkį ir jų patalpina į eilutės pabaigą. Išvesti savybės $table masyvą HTML lentele. Pademonstruokite veikimą.

class lentele{
    public $tbl = [];
    function l_prideti($q1){
        $q2 = 0;
        foreach ($q1 as $skc){
            $q2 += $skc;
        }
        $q1[] = $q2 / count($q1);
        $this->tbl[] = $q1;
    }
    function l_get(){
        echo '<table>';
        for ($i1 = 0; $i1<count($this->tbl); $i1++){
            echo '<tr>';
            for ($i2 = 0; $i2<count($this->tbl[$i1]); $i2++){  //cia prie $this->tbl prirasius indeksa [$i] apskaiciuoja visurki
                echo '<td>' . $this->tbl[$i1][$i2]. '</td>';
            }
            echo '</tr>';
        }
        echo '</table>';
    }
}
$q = new lentele();
$q->l_prideti([2,4,50]);
$q->l_prideti([5,43,52]);
$q->l_prideti([24,41,5]);
$q->l_get();
echo '<br>';

//7.2
//Sukurkite klasę diagnostika. Klasės savybė - $duomenys - asociatyvimis masyvas, kuriame yra diagnostikos pranesimai apie klaidas: raktas => tekstas (angliškas). Padaryti funkcija, kuri pagal kodą (funkcijos parametras) gražina klaidos pranešimo tekstą. Sukurti lituanizuotą diagnostikos klasę diagnostika_lt, kuri paveldi klasę diagonostika ir turi kitą diagnostikos pranešimų masyvą (pakeičiantį originalą), kur kodai yra tie patys, o tekstai - lietuviški. Išbandyti abi klases kreipiantis į funkciją tuo pačiu kodu. Jeigu kodo masyve nėra, tai reikia gražinti pranešimą "Code not found" ("Kodas nerastas")

class diagnostika {
    public $duom = ['pirmas' => 'error1', 'antras' => 'error2', 'trecias' => 'error3'];
    function f_parametras($err){
        if ($this->duom[$err]){
            return $this->duom[$err];
        }
    }
}
$r = new diagnostika();
echo $r->f_parametras('antras') . '<br>';

class diagnostika_lt {
    public $duom = ['pirmas' => 'klaida1', 'antras' => 'klaida2', 'trecias' => 'klaida3'];
    function f_parametras($err){
        if ($this->duom[$err]){
            return $this->duom[$err];
        }
    }
}
$r1 = new diagnostika_lt();
echo $r1->f_parametras('antras') . '<br>';

//6.2.2
//

class auto1{
    public $sarasas =[];
    function __construct(){
        $this->sarasas = [
            ['foto1', 'Tesla', 'S', '2001', '20000', 'pastaba1'],
            ['foto2', 'BMW', 'x', '2017', '200000', 'pastaba2'],
            ['foto3', 'Audi', 'a', '2011', '2000', 'pastaba3'],
        ];
    }
    function get1(){
        echo '<table>';
        for ($i1 = 0; $i1<count($this->sarasas); $i1++){
            echo '<tr>';
            for ($i2 = 0; $i2<count($this->sarasas); $i2++){
                echo '<td>' . $this->sarasas[$i1][$i2]. '</td>';
            }
            echo '</tr>';
        }
        echo '</table>';
    }
}
$oo = new auto1();
$oo->get1();
echo '<br>';













































