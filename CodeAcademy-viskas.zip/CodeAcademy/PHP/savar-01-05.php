<?php

//1.
//Sukurkite PHP skriptą, kuriame būtų aprašyti du kintamieji. Sudėkite juos, sumą padauginkite iš PI reikšmės. Išveskite rezultatą ekrane.

$a = 4;
$a1 = 7;

echo ($a + $a1)*pi();
echo '<br>';

//2.
//Sukurkite PHP skriptą, kuriame būtų aprašytas taksi automobilio asociatyvinis masyvas, kurio raktai yra: gamintojas, modelis, metai, vairuotojai. Vairuotojai taip pat turi būti asociatyvinis masyvas, kurio raktai: vardas, pavarde, stazas.

$taxi = [
    ['gamint' => 'Tesla'],
    ['mod' => 'S'],
    ['met' => '2017'],
    ['vairuot' => [
        ['vard' => 'Jonas'],
        ['pav' => 'Jonaitis'],
        ['staz' => '5']
    ]]
];

var_dump($taxi);
echo '<br>';

//3.
//Sukurkite PHP skriptą, kuriame būtų aprašyta funkcija, su 3 parametrais: minimalus skaicius, maksimalus skaicius, kiek atsitiktinių skaiciu sugeneruoti. Funkcija gražinti atsitiktinių skaičių masyvą. Pademonstruoti funkcijos veikimą.

function pirma($min, $max, $kiek){
    $b =[];
    for ($i= 0; $i<$kiek; $i++){
        $b[$i] = rand($min,$max);
    }
    return $b;
}
var_export(pirma('3', '5', '7'));
echo '<br>';

//4.
//Sukurkite PHP skriptą, kuriame būtų aprašytas vienmatis skaičių masyvas. Masyvo kas antro elemento reikšmę cikle programiškai pakeiskite į 0.

$c = [2, 3, 4, 5, 6, 7, 8];

for ($i = 0; $i<count($c); $i++){
    if ($c[$i] % 2 != 0){
        $c[$i] = 0;

    }
}
var_export($c);
echo '<br>';

//5.
//Sukurkite PHP skriptą, kuriame būtų aprašyta klasė “dviratis”, kuri turi savybes ‐ pavadinimas, kaina. Sukurkite standartinį klasės __construct metodą, kuriam perdavus du parametrus ‐ pavadinimas, kaina ‐ perduotus parametrus padėtų į savo savybes. Panaudodami prieš tai sukurtą klasę dviratis, sukurkite klases moteriskas ir vyriskas, kurios paveldi dviratis klasę. dviratis klasę papildykite metodu “info”, kuris išvestų suformatuotą eilutę “pavadinimas, kaina”. moteriskas klasėje perrašykite metodą info, pakeisdami išvedamą eilutę į “pavadinimas, kaina: moteriskas”. moteriskas ‐ tiesiog paprastas žodis. vyriskas klasėje perrašykite metodą info, pakeisdami išvedamą eilutę į “pavadinimas, kaina: vyriskas”. vyriskas ‐ tiesiog paprastas žodis. Patkrinkite visų trijų klasių metodo “info” veikimą.

class dviratis{
    public $pavadinimas;
    public $kaina;
    function __construct($pav, $kai){
        $this->pavadinimas = $pav;
        $this->kaina = $kai;
    }
    function info(){
        $s = "Pavadinimas: %s, Kaina: %s";
        return sprintf($s, $this->pavadinimas, $this->kaina);
    }
}
$d = new dviratis('Pirmas', '200');
echo $d->info() . '<br>';

class moteriskas extends dviratis{
    function infoMot(){
        $s1 = "Pavadinimas: %s, Kaina: %s (moteriskas)";
        return sprintf($s1, $this->pavadinimas, $this->kaina);
    }
}
$d1 = new moteriskas('Antras', '300');
echo $d1->infoMot() . '<br>';

class vyriskas extends dviratis{
    function infoVyr(){
        $s2 = "Pavadinimas: %s, Kaina: %s (vyriskas)";
        return sprintf($s2, $this->pavadinimas, $this->kaina);
    }
}
$d2 = new vyriskas('Trecias', '400');
echo $d2->infoVyr() . '<br>';

//6.
//Sukurkite PHP skriptą, kuriame aprašykime klasę numberList, kurioje būtų viena savybė ‐ $numbers, kuri bus masyvas, taip pat būtų metodas add($number), kuris prideda naują skaičių į masyvą sąvybę $numbers. Sukurkite metodą delMin(), kuris pašalina mažiausią masyve sąvybėje esantį skaičių. sukurkite funkciją getInfo(), kuris išveda skaičius esančius savybėje.

class numberList {
    public $numbers = [];
    function add(){
        for ($i = 0; $i<5; $i++){
            $this->numbers[] = rand(1, 5);
        }
    }
    function delMin(){
        $min = $this->numbers[0];
        $min_i = 0;
        for ($i=0; $i<count($this->numbers); $i++){
            if ($this->numbers[$i] < $min ){
                $min = $this->numbers[$i];
                $min_i = $i;
            }
        }
        unset($this->numbers[$min_i]);
    }
    function getInfo(){
        foreach ($this->numbers as $number){
            echo $number . ' ' . '<br>';
        }
    }

}
$e = new numberList();
$e->add();
$e->getInfo();
echo '<br>';
$e->delMin();
$e->getInfo();

//7.
//



























