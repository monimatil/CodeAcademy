<?php
class zmogus {
    public $vardasss;
    public $pavardeee;
    public $amziusss;
    function __construct($va, $pa, $amz) {
        $this->vardasss = $va;
        $this->pavardeee = $pa;
        $this->amziusss = $amz;
    }
    static function keisti($s){
        return ucfirst(strtolower($s));
    }
    public function keisti2($s){
        return ucfirst(strtolower($s));
    }
}
class asmenys extends asmuo {
    function keisti2($s)
    {
        return strtoupper($s) . ' ' . parent::keisti2($s);  // irasius ir parent prie naujo egzemlioriaus isveda seno masyvo egzemplioriu
    }
}

echo zmogus::keisti('tOmas') . '<br>';  //statine funkcija leidzia isvest be egzempliotiaus
//echo asmuo::keisti2('tOmas') . '<br>';  //klaida

$zm = new zmogus('jonas', 'jonaitis',23);
echo $zm->keisti2('tOmas') . '<br>';   // kad isvestu be klaidos butina sukurti egzemplioriu

$zmg = new zmogus('antanas', 'jonaitis',23);  //isvedimas is klases kuri paveldejo pirmos klase
echo $zmg->keisti2('tOmas') . '<br>';