
$a = 4;
$b = 5;
 echo $a + $b;
