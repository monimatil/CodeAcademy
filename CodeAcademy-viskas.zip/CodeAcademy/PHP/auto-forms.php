<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form>
    <label>Gamintojas: </label><input name="g" type="text"><br>
    <label>Modelis: </label><input name="mod" type="text"><br>
    <label>Metai: </label><input name="m" type="text"><br>
    <input type="submit" value="Vykdyti uzklausa">
</form>
<?php
class handlerForm {

    public $text;
    function toText($g, $mod, $m){
        $sablonas = 'Gamintojas: %s, Modelis: %s, Metai: %s';
        return sprintf($sablonas, $g, $mod, $m);
    }
}
$masina = new handlerForm();
if (isset($_GET['g']) && isset($_GET['mod']) && isset($_GET['m'])){
    echo $masina->toText($_GET['g'], $_GET['mod'], $_GET['m']);
}
else echo 'Isvesti duomenis';
// echo "Gamintojas: " . $_GET['g'] . ....

?>
</body>
</html>
