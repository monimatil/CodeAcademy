<?php
try {
    $cnn = new PDO('mysql:host=localhost:8889;dbname=nests', 'monimati', '7x10mm96');

    $cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $res = $cnn->query('select aut_gamintojas from auto');
    while ($a = $res->fetch()) {
        echo $a['aut_gamintojas'] . '<br>';
    }
}
catch (PDOException $err) {
    echo $err->getMessage();
}
