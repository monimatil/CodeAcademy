<?php

class zmogus {         //isvardinam savybes
    public $vardas;
    public $pavarde;
    public $gdata;

    function info(){   // objekte viskas yra daroma su roduklem tai kas masyve bv = ir kabutes objekte rasome rodykle
        $this->vardas = 'Andrius';
        $this->pavarde = 'Andriukaitis';
        $this->gdata = '1990-12-10';
        $s = 'Vardas: %s, Pavarde: %s, Gimimo data: %s';
        return sprintf($s, $this->vardas, $this->pavarde, $this->gdata);
    }
}

$zm = new zmogus();         // egzemplioriaus kurimas
echo $zm->info() . '<br>';  // kvieciame funkcija. isveda sablona su visom savybem
echo $zm->vardas . '<br>';  // nuskaitom savybe. isveda tik varda
$zm->vardas = 'Tomas';      //pakeiciam savybe
echo $zm->vardas . '<br>';  //nuskaitom pakeista savybe


class darbuotojas {         //isvardinam savybes
    public $vardas = 'Nezinomas';
    public $pavarde = 'Nezinoma';
    public $alga = '0';

    function info(){
        $s = 'Vardas: %s, Pavarde: %s, Alga: %s $';
        return sprintf($s, $this->vardas, $this->pavarde, $this->alga);
    }
}
$db = new darbuotojas();     // egzemplioriaus kurimas
echo $db->info() . '<br>';   // su sita eilute iskvieciame funkcija

$db->vardas = 'Jonas';
echo $db->info() . '<br>';

$db->pavarde = 'Jonaitis';
$db->alga = '1000';        // rasom kabutese nes pridedam dolerio zenkla, be jo kabuciu galima nedeti
echo $db->info() . '<br>';

//3 budais isvedam tiesiog masyva
var_dump($db);
echo '<br>';

var_export($db);
echo '<br>';

echo json_encode($db) . '<br>';

//unset($db)
//  ^
// /|\
//  |
//kaip taupyti atminti. panaikinti objekta, bet ne clase




