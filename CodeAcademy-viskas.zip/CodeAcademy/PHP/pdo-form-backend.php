<?php

$frm = new PDO('mysql:host=localhost:8889;dbname=nests', 'monimati', '7x10mm96');

$r=$frm->prepare('insert into auto (aut_gamintojas,aut_modelis,aut_metai,aut_kaina) values(:gamintojas,:modelis,:metai,:kaina)');

$x=$r->execute([
    ':gamintojas' => $_POST['gamintojas'],
    ':modelis' => $_POST['modelis'],
    ':metai' => $_POST['metai'],
    ':kaina' => $_POST['kaina']
]);

$sql = 'select * from auto';
$r = $frm->query($sql);
echo '<table>';
echo '<th>Gamintojas</th><th>Modelis</th><th>Metai</th><th>Kaina</th>';
while ($row=$r->fetch()){
    echo '<tr>';
    echo '<td>' . $row['aut_gamintojas'].'</td>';
    echo '<td>' . $row['aut_modelis'].'</td>';
    echo '<td>' . $row['aut_metai'].'</td>';
    echo '<td>' . $row['aut_kaina'] . '</td>';
    echo '</tr>';
}
echo '</table>';
echo '<a href="pdo-form-frontend.html">Grizti i forma</a>';