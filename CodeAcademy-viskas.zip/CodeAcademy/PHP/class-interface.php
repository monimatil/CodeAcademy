<?php

// Declare the interface 'iTemplate'
interface iTemplate                           //class
{
    public function setVariable($name, $var);  //funkciju paskelbimas
    public function getHtml($template);
}

// Implement the interface // idegia, relizuoja class
// This will work

class Template implements iTemplate
{
    private $vars = array();

    public function setVariable($name, $var)
    {
        $this->vars[$name] = $var;

        var_export($this->vars);
    }

    public function getHtml($template)
    {
        foreach($this->vars as $name => $value) {
            $template = str_replace('{' . $name . '}', $value, $template);
        }

        return $template;
    }
}

$b = new Template();
$b->setVariable('a', 5);
