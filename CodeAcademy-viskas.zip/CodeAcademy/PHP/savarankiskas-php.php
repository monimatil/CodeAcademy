<?php
$d = 'daugyba';
function daugyba($a= '8', $b = '2') {
    return $a * $b;
}
echo daugyba('8', '2');
?>
