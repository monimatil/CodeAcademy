<?php

echo $_GET['vardas']. ' * ' .$_GET['pavarde']. ' * ' .$_GET['gdata'];

