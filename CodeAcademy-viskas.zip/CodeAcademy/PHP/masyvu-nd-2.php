<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<?php

function svecias($vardas, $pavarde, $maistas){
    return [
        'Vardas' => ucfirst(strtolower($vardas)),
        'Pavarde' => ucfirst(strtolower($pavarde)),
        'Maistas' => ucfirst(strtolower($maistas)),
    ];
}
$x = svecias('Tomas', 'Tomaitis', 'Mesa');
var_export($x);                  //1. isvedam masyva

echo '<br>';

$sveciai = [];

$sv = svecias('Ana', 'Anaite', 'Zuvis');
//var_export($sv);                  //2. isvedam masyva
$raktas = strtolower($sv['Vardas']) . ' ' . strtolower($sv['Pavarde']);
$sveciai[$raktas] = $sv;
echo '<br>';
echo $raktas;     // isveda ana anaite viska mazosiom(strtolower)

$sv = svecias('Jonas', 'Jonaitis', 'Salotos');
$raktas = strtolower($sv['Vardas']) . ' ' . strtolower($sv['Pavarde']);
$sveciai[$raktas] = $sv;
echo '<br>';
echo $raktas;      // isveda jonas jonaitis viska mazosiom(strtolower)


$sv = svecias('Vladas', 'Vladaitis', 'Sriuba');
$raktas = strtolower($sv['Vardas']) . ' ' . strtolower($sv['Pavarde']);
$sveciai[$raktas] = $sv;
echo '<br>';
echo $raktas;      // isveda vladas vladaitis viska mazosiom(strtolower)

$sv = svecias('Antanas', 'Antanaitis', 'Kose');
$raktas = strtolower($sv['Vardas']) . ' ' . strtolower($sv['Pavarde']);
$sveciai[$raktas] = $sv;

krsort($sv);
echo '<br>';
echo $raktas;   // isveda antanas antanaitis turejo surusiuot su ksort

function eilute($svecias){
    return "<tr><td>".$svecias['Vardas']."</td><td>".$svecias['Pavarde']."</td><td>".$svecias['Maistas']."</td></tr>";
}
?>

<table>
    <th>Vardas</th><th>Pavarde</th><th>Maistas</th>
    <?php
    foreach ($sveciai as $key => $value )
        echo eilute($value);

    ?>
</table>

</body>
</html>
