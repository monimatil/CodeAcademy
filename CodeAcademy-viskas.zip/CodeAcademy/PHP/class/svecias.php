<?php


class svecias extends asmuo
{
    public $maistas;

    function __construct($v, $p, $a, $m)
    {
        $this->vardas = $v;
        $this->pavarde = $p;
        $this->amzius = $a;
        $this->maistas = $m;
    }
}