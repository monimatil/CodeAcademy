<?php


class automobilis{
    public $gamintojas;
    public $modelis;
    public $metai;
    function __construct($gam, $mod, $met){
        $this->gamintojas = $gam;
        $this->modelis = $mod;
        $this->metai = $met;
    }

}