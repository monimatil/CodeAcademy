<?php

class servisas extends automobilis {

    function info(){
        $s = 'Gamintojas: %s, Modelis: %s, Metai: %s';
        return sprintf($s, $this->gamintojas, $this->modelis, $this->metai);
    }
}