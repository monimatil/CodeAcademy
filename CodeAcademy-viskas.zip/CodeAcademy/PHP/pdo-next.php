<?php

$cnn = new PDO('mysql:host=localhost:8889;dbname=nests', 'monimati', '7x10mm96');

$kaina = 50000;
//uzklausa paruosiame naudoti serveryje
$res = $cnn->prepare('select aut_gamintojas from auto where aut_kaina>=:kaina');
//pranesam parametrus
$x = $res->execute([':kaina' => $kaina]);
while ($a = $res->fetch()){
    echo $a['aut_gamintojas'] . '<br>';
}