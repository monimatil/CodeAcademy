<?php

function darbuotojas($a, $b, $c){
    return[
        'Vardas' => ucfirst(strtolower($a)),
        'Pavarde' => ucfirst(strtolower($b)),
        'Profesija' => ucfirst(strtolower($c)),
    ];
}
$petras = darbuotojas('Vardas', 'Pavarde', 'Profesija');

function isvedimas($d){
    $sablonas = 'Darbuotojas %s %s yra puikus %s';

    $vardas = $d['Vardas'];
    $pavarde = $d['Pavarde'];
    $profesija = $d['Profesija'];

    $tekstas = sprintf($sablonas, $vardas, $pavarde, $profesija);

    return $tekstas;

}
 $kolegos = [];

$kolegos [] = darbuotojas('Petras', 'Petraitis', 'Vadybininkas');
$kolegos [] = darbuotojas('Jonas', 'Jonaitis', 'Kulinaras');
$kolegos [] = darbuotojas('Antanas', 'Antanaitis', 'Mokytojas');

echo '<hr>';
echo isvedimas($kolegos[2]);
echo '<hr>';
echo isvedimas($kolegos[1]);
echo '<hr>';
echo isvedimas($kolegos[0]);

function html($k){

    $sablonas =
        '<table>
    <tr>
       <td>%s</td><td>%s</td><td>%s</td>
    </tr>
    <tr>
       <td>%s</td><td>%s</td><td>%s</td>
    </tr>
    <tr>
       <td>%s</td><td>%s</td><td>%s</td>
     </tr>
 </table>';

    $d1 = $k[0];
    $d2 = $k[1];
    $d3 = $k[2];

    $html = sprintf($sablonas,
        $d1 ['Vardas'], $d1 ['Pavarde'], $d1 ['Profesija'],
        $d2 ['Vardas'], $d2 ['Pavarde'], $d2 ['Profesija'],
        $d3 ['Vardas'], $d3 ['Pavarde'], $d3 ['Profesija']
    );
    return $html;
}
echo '<br>';
echo html ($kolegos);