<?php

session_start();

include 'class/asmuo.php';
include 'class/svecias.php';

$asmuo = new asmuo('jonas', 'jonaitis',23);
var_export($asmuo) . '<br>';

$svecias = new svecias('jonas', 'jonaitis',25, 'zuvis');
var_export($svecias) . '<br>';

echo json_encode($svecias) . '<br>'; //isveda tvarkinga masyva

echo serialize($svecias);  //serialize - objekto surinkimas ir sudeliojimas technineje formoje

$x = serialize($svecias); // daro teksta
$y = unserialize($x); //is teksto i objekta

$_SESSION['asmuo'] = $x;

var_export($y) . '<br>';

if (isset($_SESSION['cnt'])){
    $cnt = $_SESSION['cnt'];
    $cnt++;                   //kiekviena karta po viena padides
    $_SESSION['cnt'] = $cnt;
    //$_SESSION['cnt]++;
}else $_SESSION['cnt'] = 1;  //prasideda nuo 1
echo ' cnt: ' . $_SESSION['cnt'] . '<br>';  //skaiciuoje refresus(perkrauni psl ir skaicius padideja)