<?php
// 1. dvimatis masyvas
$m = [
    ['BMW', '301i', '2000'],
    ['Audi', '100', '1990'],
    ['Honda', 'civic', '2005']
];
$x = 3;
$y = 3;

$m[0][2] = '3000';  //pakeiciam pirmos masyvo paskutine reiksme taso masyvo pavad($m) tada kuris masyvas ([0]), ir kuri masyvo reiksme ([2]);

echo '<table>';
for ($i=0; $i<$x; $i++){
    echo '<tr>';
    for ($j=0; $j<$y; $j++){
        echo '<td>' . $m[$i][$j] . '</td>';
    }
    echo '</tr>';
}
echo '</table>';

