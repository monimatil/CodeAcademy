<!--
//8.
//ukurkite HTML dokumentą 11.2-frontend.html su įvedimo formą. Forma turėtu turėti laukus : 3x tekstiniai laukai: Vardas, Pavardė, Gimimo data. Forma turėtu būti nusiųsta į 11.2-backend.php failą metodu POST. 11.2-backend.php faile PDO pagalba įrašykite duomenis į duomenų bazės lentelę 'asmenys'. Backend faile įdėkite nuorodą (linką) į įvedimo formos html dokumentą.
-->
<?php

$g = new PDO('mysql:host=localhost:8889;dbname=nests', 'monimati', '7x10mm96');
$g1 = $g->prepare('insert into asmenys (asm_var, asm_lyt, asm_data) values(:vardas, :lytis, :data)');

$g2=$g1->execute([
    ':vardas' => $_POST['vardas'],
    ':lytis' => $_POST['lytis'],
    ':data' => $_POST['data']
]);


echo '<a href="form-savar-01-04.html">Grizti i forma</a><br>';