<?php
/* be klases ir funkciju tiesiog su echo viska isveda


echo '<table>';
echo '<th>Salys</th><th>Sostine</th><th>Gyventoju skaicius</th>';
echo '<tr><td>'.$_GET['salis'].'</td><td>'.$_GET['sostine'].'</td><td>'.$_GET['gyvsk'].'</td></tr>';
echo '</table>';



echo '<a href="salys-get-html.html">Atgal</a>';
*/

class salis{
    function info($salis, $sostine, $gyvsk){
        return '<tr><td>'.$salis.'</td><td>'.$sostine.'</td><td>'.$gyvsk.'</td></tr>';
    }
}
$s = new salis();
echo '<table>';
echo '<th>Salys</th><th>Sostine</th><th>Gyventoju skaicius</th>';
echo $s->info($_GET['salis'], $_GET['sostine'], $_GET['gyvsk']);
echo '</table>';

echo '<a href="salys-get-html.html">Atgal</a>';