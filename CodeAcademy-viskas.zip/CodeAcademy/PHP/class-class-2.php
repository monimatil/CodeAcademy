<?php

session_start();
echo ' cnt: ' . $_SESSION['cnt'] . '<br>';  // sitaam psl matau tik skaiviu kuris keiciasi nuo to kiek kartu refresini class-class-1

$svecias = unserialize($_SESSION['asmuo']);

var_export($svecias) . '<br>';