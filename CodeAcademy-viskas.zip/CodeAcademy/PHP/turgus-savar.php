<?php

class turgus{
    public $automobiliai;

    function automobilis($gamintojas, $modelis, $metai, $kaina){
        if (!isset($this->automobiliai)) $this->automobiliai=[]; //su sita eil sukuriam tuscia masyva
        $this->automobiliai[] = [         // i padarom ASOCIATYVINI MASYVA su parametrais
            'gamintojas' => $gamintojas,
            'modelis' => $modelis,
            'metai' => $metai,
            'kaina' => $kaina
        ];
    }
    // minimalia kaina
    function minKaina(){
        $min = $this->automobiliai[0]['kaina'];
        for($i = 0; $i<count($this->automobiliai); $i++){
            if ($this->automobiliai[$i]['kaina'] < $min) $min = $this->automobiliai[$i]['kaina'];
        }
        return $min;
    }
}
$auto = new turgus();
$auto->automobilis('Bmw', '2', '2009', '200000');
$auto->automobilis('Tesla', 's', '2005', '2000');

echo $auto->minKaina();