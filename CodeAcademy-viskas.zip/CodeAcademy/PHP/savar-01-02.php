<?php

$a = 3;
$b = 6;
$c = 2;

echo $a**2 + $b**2 + $c**2;
echo '<br>';

// 2.
//asociatyvinis masyvas naudojant rektus
$d = ['Vardas' => 'Jonas', 'Pavarde' => 'Jonaitis', 'Data' => '2000-12-22', 'Lytis' => 'Vyras'];

var_export($d);
echo '<br>';

//3.
function vid($e, $f, $g, $h){
    $i = $e + $f + $g + $h;
    return $i / 4;
}
echo vid('2','3','4','5');
echo '<br>';

//4.
$j = ['var' => 'petras', 'pav' => 'petraitis', 'amz' => 'dvidesimt', 'lyt' => 'vyras'];
foreach ($j as $key => $value){
    $j[$key] = ucfirst(strtolower($value)) .'.';

}
var_export($j);
echo '<br>';

//5.
class automobilis{
    public $agamintojas;
    public $amodelis;
    public $ametai;
    function __construct($gam, $mod, $met){
        $this->agamintojas = $gam;
        $this->amodelis = $mod;
        $this->ametai = $met;
    }
}
$aa = new automobilis('Tesla', 'S', '2017');
var_dump($aa);
echo '<br>';