<?php
//1. kalse naudojant html lente

class svecias {
    public $vardas;
    public $pavarde;
    public $maistas;
    function __construct($vardas, $pavarde, $maistas) {
$this->vardas = ucfirst(strtolower($vardas));
$this->pavarde = ucfirst(strtolower($pavarde));
$this->maistas = ucfirst(strtolower($maistas));
}
    function eilute() {

        $s = '<tr>';
        $s.= '<td>' . $this->vardas . '</td>';
        $s.= '<td>' . $this->pavarde . '</td>';
        $s.= '<td>' . $this->maistas . '</td>';
        $s.= '</tr>';
        return $s;
    }
}
$sveciai = [];
$sveciai[] = new svecias('Jonas', 'Jonaitis', 'Mesa');
$sveciai[] = new svecias('Tomas', 'Tomaitis', 'Sriuba');
$sveciai[] = new svecias('Ana', 'Anaite', 'Kose');

//var_dump($sveciai);

echo '<table>';                                         //isveda lentele naudojant html
echo '<th>Vardas</th><th>Pavarde</th><th>Maistas</th>';
foreach($sveciai as $sv) {
    echo $sv->eilute();
}

echo '</table>';
echo '<br>';

// 2. klase naudjant eilute
class masian {
    public $gamintojas;
    public $modelis;
    public $metai;
    function __construct($gamintojas, $modelis, $metai){
        $this->gamintojas = ucfirst(strtolower($gamintojas));
        $this->modelis = ucfirst(strtolower($modelis));
        $this->metai = ucfirst(strtolower($metai));
    }
    function info() {
        $s = 'Gamintojas: %s, Modelis: %s, Metai: %s';
        return sprintf($s, $this->gamintojas, $this->modelis, $this->metai);
    }
}
$masinos = [];
$masinos[] = new masian('BMW', 'g5', '2000');
$masinos[] = new masian('Audi', 'a6', '2015');
$masinos[] = new masian('Tesla', 's', '2017');


foreach ($masinos as $ma){
    echo $ma->info() . '<br>';                         //isveda eilutem naudojant sabloa
}
echo '<br>';

// 3.
class zmogus {
    const copy = 'CODEACADEMY';
    const aaa = 'bbb';
    public $vardass;
    public $pavardee;
    public $amzius;
    private $sablonas = 'Vardas: %s, Pavaede: %s, Amzius: %s';
    function __construct($v, $p, $a = 'Nezinomas'){
        $this->vardass = $this->pakeisti($v);
        $this->pavardee = $this->pakeisti($p);
        $this->amzius = $a;
    }
    private function pakeisti($s){
        return ucfirst(strtolower($s));
    }
    public function eilutee(){
        return zmogus::copy . ': ' . sprintf($this->sablonas, $this->vardass, $this->pavardee, $this->amzius);
    }
}

$z = new zmogus('jonas', 'jonaitis', 25);
echo $z->vardass . '<br>';    //isvede varda - jonas
echo $z->eilutee() . '<br>';

//echo $z->sablonas . '<br>';  //bus klaida


define('aaa', 'Labas');               // aaa konstantes pavadinimas
echo aaa . '<br>';                    // labas reiksme priskirta konstantei

echo zmogus::copy . '<br>';

//4. su paveldejimu
class mokinys extends zmogus {
    public $pazymys;
    function __construct($v, $p, $a, $paz){
        $this->vardass = $v;
        $this->pavardee = $p;
        $this->amzius = $a;
        $this->pazymys = $paz;
    }

}
$mo = new mokinys('petras', 'petraitis', 25, 10);
var_export($mo);
echo '<br>';
echo mokinys::copy . '<br>';




