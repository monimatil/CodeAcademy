

<?php
//var_dump($_POST);

include 'auto.php';
$o2 = new auto();

$del_tikrinam = $o2->delete($_POST['delete']);

if ($del_tikrinam){
    echo '<div class="jumbotron p-2 bg-success site-body mt-1 mx-auto"><p style="color: white; font-size: 32px; text-align: center"> '.$o2->message.'</p></div><br>';

}
else{
    echo '<div class="jumbotron p-2 bg-danger site-body mt-1 mx-auto"><p style="color: white; font-size: 32px; text-align: center"> '.$o2->message.'</p></div><br>';

}

echo '<a href="index.php"><button class="btn btn-info mt-2 mx-2">Automobiliu sarasas</button></a><br>';
