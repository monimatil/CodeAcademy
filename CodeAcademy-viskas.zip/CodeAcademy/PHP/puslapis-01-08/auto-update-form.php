
<?php
include 'auto.php';
$mas = false;

if (isset($_POST['update-form'])){
    $auto = new auto();
    $mas = $auto->get($_POST['update-form']);
}
if ($mas == false){
    $mas = [
        'id' => '',
        'gamintojas' => '',
        'modelis' => '',
        'metai' => '',
        'kaina' => '',
        'pastabos' => '',
        'nuotrauka' => '',
        'mime' => '',
    ];
}

//var_export($ins_tikrinam);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Naujo automobilio ivedimas</title>

</head>
<body>

<form method="post" action="auto-update.php" enctype="multipart/form-data">
    <div class="form-group mt-2 mx-4">
        <label for="gamintojas">Gamintojas:</label>
        <input type="text" class="form-control" id="gamintojas" name="gamintojas" value="<?php echo $mas['gamintojas'] ?>">
        <label for="modelis">Modelis:</label>
        <input type="text" class="form-control" id="modelis" name="modelis" value="<?php echo $mas['modelis'] ?>">
        <label for="metai">Metai:</label>
        <input type="text" class="form-control" id="metai" name="metai" value="<?php echo $mas['metai'] ?>">
        <label for="kaina">Kaina:</label>
        <input type="text" class="form-control" id="kaina" name="kaina" value="<?php echo $mas['kaina'] ?>">
        <label for="pastabos">Pastabos:</label>
        <textarea type="text" class="form-control" id="pastabos" name="pastabos"><?php echo $mas['pastabos'] ?></textarea>
        <label for="nuotrauka">Pasirinkite nuotraukos faila:</label><br>
        <input type="file" name="nuotrauka"><br>
        <input type="submit" class="btn btn-info mt-2"  value="Vykdyti">
    </div>
    <input type="hidden" name="id" value="<?php $mas['id']?>">
</form>

</body>
</html>

