<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="UTF-8">
    <title>Automobilių nuomos internetinė informacinė sistema - šalinimas | UAB Auto 7/24</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.6/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" type="text/css">

    <link rel="stylesheet" href="/kontroliniai/darbas/auto.css" type="text/css">

</head>
<body>
<div class="container-flex">
    <div class="site-header">
        <!--mx= margin x asimi-->
        <table class="mx-auto w-100">
            <tr>
                <!--logotipo-->
                <td><img class="site-logo" src="foto-01-08/logo-site.jpeg"></td>
                <!--uzraso-->
                <td>
                    <h1 class="site-titel">Automobiliu nuoma 24/7</h1>
                    <div class="row site-header-top-grid">
                        <div class="col p-0"><button class="btn m-0 p-0 pb-1 pl-2 pr-2"><i class="fa fa-phone pr-1" aria-hidden="true"></i></button>+370 687993</div>
                        <div class="col p-0 pl-1"><a href="https://www.facebook.com"><i class="fa fa-facebook-square" aria-hidden="true"></i></a></div>
                        <div class="col p-0 pl-1"><a href="https://www.twitter.com"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></div>
                        <div class="col p-0 pl-1"><a href="https://www.instagram.com"><i class="fa fa-instagram" aria-hidden="true"></i></a></div>

                    </div>
                </td>
            </tr>
        </table>
    </div>
    <div class="site-menu">
        <div class="mx-auto">
            <nav class="navbar navbar-expand-sm m-0 p-0">
                <ul class="navbar-nav nav-pills">
                    <li class="nav-item active">
                        <a class="nav-link" href="/PHP/puslapis-01-08/"><i class="fa fa-home" aria-hidden="true"></i>Titulinis</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/PHP/puslapis-01-08/auto-action.php"><i class="fa fa-car" aria-hidden="true"></i>Įdėti naują automobilį</a>
                    </li>
                </ul>
            </nav>
        </div>
        <?php
        $mas = false;
        if (isset($_POST['rent-form'])) {
            include 'auto.php';
            $auto = new auto();
            $mas = $auto->get($_POST['rent-form']);
            $message = $auto->message;
        } else $message = 'Neleistinas veiksmas';
        if ($car !== false){
            ?>
            <div class="jumbotron p-2 bg-success">
                <p style="color: white; font-size: 32px"><?php echo sprintf("Automobilis %s %s (%s m.) užsakytas", $mas["gamintojas"], $mas["modelis"], $mas["metai"]) ?></p>
            </div>
            <table class="table border">
                <tr><td>Vardas</td><td><?php echo $_POST['vardas'] ?></td></tr>
                <tr><td>Pavardė</td><td><?php echo $_POST['pavarde'] ?></td></tr>
                <tr><td>Kaina</td><td><?php echo $mas['kaina'] * $_POST['dienos'] ?> EUR</td></tr>
                <tr><td>Data</td><td><?php echo $_POST['data'] ?></td></tr>
                <tr><td>Dienų</td><td><?php echo $_POST['dienos'] ?></td></tr>
                <tr><td>Pasiimti</td><td><?php echo $_POST['pasiimti'] ?></td></tr>
                <tr><td>Atiduoti</td><td><?php echo $_POST['atiduoti'] ?></td></tr>
            </table>
            <?php
        }
        else {
            ?>
            <div class="jumbotron p-2 bg-danger">
                <p style="color: white; font-size: 32px"><?php echo $message ?></p>
            </div>
            <?php
        }
        ?>
        echo '<a href="index.php"><button class="btn btn-info mt-2 mx-2">Automobiliu sarasas</button></a><br>';
    </div>
</body>
</html>

