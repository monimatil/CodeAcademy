<?php

// klase kurioj egzemlioriu negalima pagamint. tik paveldejus klase toj klasej kuri paveldejo pirma galima sukurti egzemlioriu

abstract class AbstractClass
{
    // Force Extending class to define this method
    abstract protected function getValue();
    abstract protected function prefixValue($prefix);

    // Common method
    public function printOut() {
        echo $this->getValue() . "\n";
    }
}
 //$a = new AstractClass(); //klaide nes egzemlioriaus kurti negalima

class ConcreteClass1 extends AbstractClass
{
    protected function getValue()
    {
        return "ConcreteClass1";
    }
    public function prefixValue($prefix) {
        echo "{$prefix}_{$this->getValue()}";
    }
}
 $a = new ConcreteClass1();
$a->prefixValue('Labas');