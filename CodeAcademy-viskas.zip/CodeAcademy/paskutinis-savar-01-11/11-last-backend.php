<?php
session_start();

if(!isset($_SESSION['sesija'])){
    $_SESSION['sesija'] = [];
}

$_SESSION['sesija'][] = $_POST;

header('location: last-11.html');

$q = fopen('11-last-fe.txt', 'a');

$s = '';
foreach ($_POST as $key => $value){
    $s .= ' '.$key.'=>'.$value;
}
fwrite($q, $s);
fclose($q);