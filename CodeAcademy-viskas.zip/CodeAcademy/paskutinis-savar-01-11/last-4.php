<?php

/*
4. Sukurkite PHP skriptą, kuriame būtų aprašyti du kintamieji ir ekrane būtų išvestas tų kintamųjų dešimtainių logaritmų suma.
*/

$a1 = 6;
$a2 = 8;

echo log10($a1) + log10($a2) . '<br>';

/*
5. Sukurkite PHP skriptą, kuriame būtų aprašytas vienmatis masyvas, aprašantis vieną šalį naudojant vardinius raktus, pavyzdžiui “šalis” => “Lietuva”. Masyve turi būti laukeliai ‐ šalis, sostinė, gyventojų skaičius, plotas.
*/

$b = ['salis' => 'Lietuva', 'sostine' => 'Vilnius', 'gskiacius' => '3000000', 'plotas' => '65 300 km²' ];
var_export($b);
echo '<br>';

/*
6. Sukurkite PHP skriptą, kuriame būtų aprašyta funkcija, kuriai padavus du parametrus ‐ skaičius, funkcija turi grąžinti rezultatą ‐ visų paduotų parametrų kvadratų sumą padaugintą iš pi.
*/

function lpirma($c1, $c2){
    $c = (sqrt($c1) + sqrt($c2))*pi();
    return $c;
}
echo lpirma(3, 4) . '<br>';

/*
7. Sukurkite PHP skriptą, kuriame būtų aprašytas vienmatis masyvas iš 3 elementų ‐ teksto eilučių. Panaudodami foreach ciklą ‐ pakeiskite visus masyvo elementus ‐ paversdami tekstą mažosiomis raidėmis.
 */

$d = ['paskutinis', 'savarankiskas', 'darbas', 'pries', 'egzamina'];

foreach ($d as $value){
    echo $value = strtolower($value). ' ';
}
echo '<br>';

/*
8.Sukurkite PHP skriptą, kuriame būtų aprašyta klasė “salis”, kuri turi savybes ‐ pavadinimas, sostine, gyventojai. Sukurkite standartinį klasės __construct metodą, kuriam perdavus tris parametrus ‐ pavadinimas, sostine, gyventojai ‐ perduotus parametrus padėtų į savo savybes.
*/
/*
9. Panaudodami prieš tai sukurtą klasę salis, sukurkite klases vakaru_salis ir rytu_salis, kurios paveldi salis klasę. Salis klasę papildykite metodu “informacija”, kuris išvestų suformatuotą eilutę “šalis, sostinė, gyventojai”. rytu_salis klasėje perrašykite metodą informacija, pakeisdami išvedamą eilutę į “šalis, sostinė, gyventojai (Rytų šalis)”. Rytų šalis ‐ tiesiog paprastas tekstas.
*/

class salis{
    public $pavadinimas;
    public $sostine;
    public $gyventojai;
    function __construct($pav, $sos, $gyv){
        $this->pavadinimas = $pav;
        $this->sostine = $sos;
        $this->gyventojai = $gyv;
    }
    function informacija(){
        $sablonas1 = 'Pavadinimas: %s, Sostine: %s, Gyventojai: %s,';
        return sprintf($sablonas1, $this->pavadinimas, $this->sostine, $this->gyventojai);
    }
}
$e1= new salis('Lietuva', 'Vilnius', '200000');
echo $e1->informacija() . '<br>';

class vakaru_salis extends salis{
    function v_informacija(){
        $sablonas2 = 'Pavadinimas: %s, Sostine: %s, Gyventojai: %s (Vakariu šalis)';
        return sprintf($sablonas2, $this->pavadinimas, $this->sostine, $this->gyventojai);
    }
}
$e2= new vakaru_salis('Belgija', 'Briuselis', '3000000');
echo $e2->v_informacija() . '<br>';


class rytu_salis extends salis{
    function r_informacija(){
        $sablonas3 = 'Pavadinimas: %s, Sostine: %s, Gyventojai: %s (Rytų šalis)';
        return sprintf($sablonas3, $this->pavadinimas, $this->sostine, $this->gyventojai);
    }
}
$e3= new rytu_salis('Airija', 'Dublinas', '30000');
echo $e3->r_informacija() . '<br>';

/*
10. Sukurkite PHP skriptą, kuriame aprašykime klasę countryList, kurioje būtų viena savybė ‐ $countries, kuri bus masyvas, taip pat būtų metodas insert($country), kuris papildo savybę $countries nauja šalimi. Taip pat sukurkite metodą average(), kuris grąžintų masyve sąvybėje esančių šalių pavadinimų ilgio matematinį vidurkį
*/
class countryList{
    public $countries =[];
    function insert($coun1){
        $coun2 = 0;
        foreach ($coun1 as $elem){
            $coun2 += strlen($elem);
        }
        $coun1[] = $coun2 / count($coun1);
        $this->countries[] = $coun1;
    }
    function average(){
        echo '<table>';
        for ($i1 = 0; $i1<count($this->countries); $i1++){
            echo '<tr>';
            for ($i2 = 0; $i2<count($this->countries[$i1]); $i2++){
                echo '<td>' . $this->countries[$i1][$i2]. '</td>';
            }
            echo '</tr>';
        }
        echo '</table>';
    }
}
$q = new countryList();
$q->insert(['lietuva','estija','latvija']);
$q->insert(['anglija','vokietija','amerika']);
$q->insert(['prancuzija','canada','rusija']);
$q->average();







