<?php
//Užduotis: "Tarkime turime lentelę duomenų bazėje ‘salys’ su laukais ‘id, salis, sostine, gyventojai’. Parašykite SQL užklausą gauti visus duomenis apie 3 šalis, turinčias daugiausiai gyventojų"


$naujas = new PDO('mysql:host=localhost:8889;dbname=nests', 'monimati', '7x10mm96');

$res = $naujas->prepare('SELECT * FROM salys ORDER BY s_gyv desc limit 0,3');
$x = $res->execute();
while ($a = $res->fetch()){
    echo $a['s_pav'] . ' ' . $a['s_sos'] . ' ' . $a['s_gyv'] .'<br>';
}
