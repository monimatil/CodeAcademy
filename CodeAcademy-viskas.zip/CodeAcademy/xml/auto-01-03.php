<?php

$xml = simplexml_load_file('automobiliai-01-03');

$rezult = $xml->xpath("row");
echo '<table>';
foreach ($rezult as $record){
    echo '<tr>';
    echo '<td>' .trim($record->gamintojas) . '</td>';
    echo '<td>' .trim($record->modelis) . '</td>';
    echo '<td>' .trim($record->metai) . '</td>';
    echo '</tr>';
}
//1.
echo '</table>' . '<br>';                      // isveda lentele su visais elementais is xml

$rezult = $xml->xpath("row[@id='bmw']");
echo '<table>';
foreach ($rezult as $record){
    echo '<tr>';
    echo '<td>' .(string)$record['id'] . '</td>';  //su sita eilute isveda ir id taga
    echo '<td>' .trim($record->gamintojas) . '</td>';
    echo '<td>' .trim($record->modelis) . '</td>';
    echo '<td>' .trim($record->metai) . '</td>';
    echo '</tr>';
}
//2.
echo '</table>' . '<br>';                      //isveda bmw nes tik jam davem id, tik jo ieskom

echo htmlspecialchars($xml->asXML()) . '<br>'; // viska ismeta uzkoduoati

